package es.cfc.main;

import es.cfc.models.Animal;
import es.cfc.models.Perro;

public class AppMain {

	public static void main(String[] args) {
		
		Animal animal = new Perro("Fifi", true, 3, 111, 295.95, "Pastor aleman", true);
		
		System.out.println(animal);

	}

}
