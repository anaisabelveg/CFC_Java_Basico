package es.cfc.models;

public class Perro extends Animal implements ProductoVenta {

	private int codigo;
	private double precio;

	private String raza;
	private boolean vacunado;

	public Perro() {
		// TODO Auto-generated constructor stub
	}

	public Perro(String nombre, boolean domestico, int edad, 
			int codigo, double precio, String raza, boolean vacunado) {
		super(nombre, domestico, edad);
		this.codigo = codigo;
		this.precio = precio;
		this.raza = raza;
		this.vacunado = vacunado;
	}

	@Override
	public int getCodigo() {
		return codigo;
	}

	@Override
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	@Override
	public double getPrecio() {
		return precio;
	}

	@Override
	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public String getRaza() {
		return raza;
	}

	public void setRaza(String raza) {
		this.raza = raza;
	}

	public boolean isVacunado() {
		return vacunado;
	}

	public void setVacunado(boolean vacunado) {
		this.vacunado = vacunado;
	}

	@Override
	public String toString() {
		return "Perro [codigo=" + codigo + ", precio=" + precio + ", raza=" + raza + ", vacunado=" + vacunado
				+ ", toString()=" + super.toString() + "]";
	}
	
	

}
