package es.cfc.models;

public interface ProductoVenta {
	
	// Todos los metodos de una interface son public y abstract
	int getCodigo();
	void setCodigo(int codigo);
	
	public abstract double getPrecio();
	public void setPrecio(double precio);
	

}
