package es.cfc.bucle_while;

public class Ejercicio4 {

	public static void main(String[] args) {
		// Primer numero primo a partir de 198
		
		boolean encontrado = false;
		int numero = 198;
		
		while (!encontrado) {
			
			numero++;
			
			int divisor = 2;
			boolean esPrimo = true;
			
			while(divisor < numero) {
				if (numero % divisor == 0) {
					esPrimo = false;
					break;
				}
				divisor++;
			}
			
			if (esPrimo) {
				System.out.println(numero);
				encontrado = true;
			}
		}

	}

}
