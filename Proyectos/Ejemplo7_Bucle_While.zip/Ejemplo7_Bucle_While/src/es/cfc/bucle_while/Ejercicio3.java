package es.cfc.bucle_while;

public class Ejercicio3 {

	public static void main(String[] args) {
		
		// Calcular los primeros 25 numeros primos
		int contador = 0;
		int numero = 1;
		
		
		while (contador < 25) {
			
			while(numero <= 1000) {
				boolean esPrimo = true;
				
				int divisor = 2;
				while (divisor < numero) {
					if (numero % divisor == 0) {
						esPrimo = false;
						break;		
					}
					divisor++;
				}
				
				if (esPrimo) {
					System.out.println(numero);
					contador++;
				}
				
				numero++;
				
				if (contador == 25) break;
			}
			
		}

	}

}
