package es.cfc.bucle_while;

public class Ejercicio2 {

	public static void main(String[] args) {
		
		// 2 elevado a 8
		System.out.println(Math.pow(2, 8));
		
		int resultado = 1;
		int cont = 0;
		
		while (cont < 8) {
			resultado *= 2;
			cont++;
		}
		
		System.out.println("2 elevado a 8 = " + resultado);

	}

}
