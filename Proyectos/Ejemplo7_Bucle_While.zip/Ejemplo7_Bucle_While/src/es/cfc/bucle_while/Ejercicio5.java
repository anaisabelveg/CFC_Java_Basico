package es.cfc.bucle_while;

public class Ejercicio5 {

	public static void main(String[] args) {
		
		// Numeros perfectos hasta el 100

		int suma = 0;
		int numero = 1;
		
		while (numero <= 100) {
			
			int divisor = 1;
			while (divisor < numero) {
				if (numero % divisor == 0) {
					suma += divisor;
				}
				divisor++;
			}
			
			if (numero == suma) {
				System.out.println(numero);
			}
			
			suma = 0;
			numero++;
		}
	}

}
