package es.cfc.bucle_while;

public class Ejercicio1 {

	public static void main(String[] args) {
		// Factorial 17
		
		int numero = 1;
		long resultado = 1;
		
		while (numero <= 17) {
			resultado *= numero++;
		}
		
		System.out.println("17! = " + resultado );

	}

}
