package es.cfc.do_while;

public class Ejercicio2 {

	public static void main(String[] args) {
		
		// n primeros terminos de Fibonacci
		int n = 30;
		int termino1 = 0;
		int termino2 = 1;
		int termino3 = 0;

		System.out.println(termino1);
		System.out.println(termino2);

		do {
			termino3 = termino1 + termino2;
			System.out.println(termino3);

			termino1 = termino2;
			termino2 = termino3;

			n--;
		} while (n > 2);

	}

}
