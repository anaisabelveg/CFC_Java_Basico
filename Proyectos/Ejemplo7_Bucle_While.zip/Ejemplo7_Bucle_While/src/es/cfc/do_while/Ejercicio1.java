package es.cfc.do_while;

public class Ejercicio1 {

	public static void main(String[] args) {
		// 2 elevado a 8
		System.out.println(Math.pow(2, 8));

		int resultado = 1;
		int cont = 0;
		
		do {
			resultado *= 2;
			cont++;
		} while(cont < 8);

		System.out.println("2 elevado a 8 = " + resultado);

	}

}
