package es.cfc.do_while;

public class Ejercicio3 {

	public static void main(String[] args) {
		// suma numeros pares entre 10 y 50
		
		int suma = 0;
		int numero = 10;
		
		do {
			if (numero % 2 == 0) {
				suma += numero;
			}
			
			numero++;
			
		} while (numero <= 50);
		
		System.out.println("Suma: " + suma);

	}

}
