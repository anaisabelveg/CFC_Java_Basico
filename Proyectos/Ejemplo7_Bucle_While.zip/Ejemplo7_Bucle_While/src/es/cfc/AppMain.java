package es.cfc;

import java.util.Date;
import java.util.Scanner;

public class AppMain {

	public static void main(String[] args) {
		
		// los tipos primitivos se comparan con ==
		int numero1 = 6;
		int numero2 = 6;
		System.out.println("Son iguales? " + (numero1 == numero2));
		
		// los objetos se comparan con el metodo equals
		Date hoy1 = new Date(2020, 1, 18);
		Date hoy2 = new Date(2020, 1, 18);
		System.out.println("Son iguales? " + (hoy1 == hoy2));
		System.out.println("Son iguales con equals? " + (hoy1.equals(hoy2)));
		
		
		// Objeto que reconoce el teclado como dispositivo de entrada
		Scanner scanner = new Scanner(System.in);
		String clave = "curso";
		String pw = "";
		
		// Solicitar el pw al usuario hasta que acierte que es curso
		do {
			System.out.println("Introduce tu pw");
			pw = scanner.next();
		} while (!clave.equals(pw));
		
		System.out.println("Enhorabuena has acertado");
		
		// mostrar los numeros del 1 al 10
		int numero = 1;
		while (numero <= 10) {
			System.out.println(numero);
			numero++;
		}

	}

}
