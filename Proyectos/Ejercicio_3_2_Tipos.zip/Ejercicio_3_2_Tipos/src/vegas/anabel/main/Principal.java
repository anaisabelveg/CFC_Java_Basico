package vegas.anabel.main;

public class Principal {

	public static void main(String[] args) {
		
		// Numeros enteros
		byte numByte = 127;
		short numShort = 32767;
		int numInt = 788887765;
		long numLong = 6789999876543535688L;
		
		// Numeros reales
		float numFloat = 3.14F;
		double numDouble = 3.988776565443424321;
		
		// Texto
		char letra = '7';
		String texto = "Hola";
		
		// Booleano
		boolean acierto = true;
		
		// Conversion de datos
		// Convertir cualquier numero a texto
		String strByte = String.valueOf(numByte);
		
		// Convertir un texto a numero
		int numeroEntero =  Integer.parseInt("8765");
		double numeroDouble = Double.parseDouble("789656.3445");
		float numeroFloat = Float.parseFloat("789656.3445");
		
		// Convertir un numero real a un numero entero. Desechar la parte decimal.
		double resultado = 50 / 3.0;
		System.out.println(resultado);
		
		// Efectuar un casting
		int resultadoEntero = (int)resultado;
		
		// Promocion -> casting automatico
		long numeroGrande = 789;
		double altura = 1.67F;
		

	}

}
