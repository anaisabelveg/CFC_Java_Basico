package es.cfc.models;

public class Fecha {
	
	public int dia;
	public int mes;
	public int anyo;
	
	public void mostrarFecha() {
		System.out.println(dia + "/" + mes + "/" + anyo);
	}

}
