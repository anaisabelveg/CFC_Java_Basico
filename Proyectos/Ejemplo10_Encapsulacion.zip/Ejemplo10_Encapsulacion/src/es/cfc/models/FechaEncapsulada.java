package es.cfc.models;

// Una clase encapsulada, declara todas sus propiedades como privadas
// y se accede a ellas a través de métodos get() y set() publicos
public class FechaEncapsulada {

	private int dia;
	private int mes;
	private int anyo;

	// Se entiende como un metodo de lectura
	// me devuelve el contenido de la variable
	public int getDia() {
		return dia;
	}

	// Actua como un metodo de escritura
	// Establece el valor a la variable
	public void setDia(int dia) {
		if (dia > 0 && dia <= 30) {
			this.dia = dia;
		} else {
			System.out.println("Dia no es valido");
		}	
	}

	public int getMes() {
		return mes;
	}

	public void setMes(int mes) {
		if (mes > 0 && mes <= 12) {
			this.mes = mes;
		}
	}

	public int getAnyo() {
		return anyo;
	}

	public void setAnyo(int anyo) {
		if (anyo >= 2022) this.anyo = anyo;
	}

	public void mostrarFecha() {
		System.out.println(dia + "/" + mes + "/" + anyo);
	}

}
