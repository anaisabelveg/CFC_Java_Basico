package es.cfc.main;

import es.cfc.models.Fecha;
import es.cfc.models.FechaEncapsulada;

public class AppMain {

	public static void main(String[] args) {
		
		Fecha fecha = new Fecha();
		fecha.dia = 217654;
		fecha.mes = 678;
		fecha.anyo = -662022;
		
		fecha.mostrarFecha();
		
		// Fecha encapsulada
		FechaEncapsulada fechaEncapsulada = new FechaEncapsulada();
		fechaEncapsulada.setDia(217654);
		fechaEncapsulada.setMes(678);
		fechaEncapsulada.setAnyo(-662022);
		
		fechaEncapsulada.mostrarFecha();
		
		FechaEncapsulada fechaEncapsulada2 = new FechaEncapsulada();
		fechaEncapsulada2.setDia(21);
		fechaEncapsulada2.setMes(1);
		fechaEncapsulada2.setAnyo(2022);
		
		fechaEncapsulada2.mostrarFecha();
	}

}
