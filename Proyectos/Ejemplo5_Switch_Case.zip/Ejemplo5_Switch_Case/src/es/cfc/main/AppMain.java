package es.cfc.main;

public class AppMain {

	public static void main(String[] args) {
		
		int numero = 6;
		
		switch (numero) {
		case 1:
			System.out.println("Es lunes");
			break;

		case 2:
			System.out.println("Es martes");
			break;
			
		case 3:
			System.out.println("Es miercoles");
			break;
			
		case 4:
			System.out.println("Es jueves");
			break;
			
		case 5:
			System.out.println("Es viernes");
			break;
			
		case 6:
			System.out.println("Es sabado");
			break;
			
		case 7:
			System.out.println("Es domingo");
			break;
			
		default:
			System.out.println("Dia de la semana no valido");
			break;
		}
		
		
		// Ejercicio 2
		int nota = 7;
		
		switch (nota) {
		case 0:
		case 1:
		case 2:
		case 3:
		case 4:
			System.out.println("Suspenso");
			break;
		case 5:
			System.out.println("Aprobado");
			break;
		case 6:
			System.out.println("Bien");
			break;
		case 7:
		case 8:
			System.out.println("Notable");
			break;
		case 9:
		case 10:
			System.out.println("Sobresaliente");
			break;
		default:
			break;
		}
		
		
		// Ejercicio 3
		int numDivisible = 67;
		
		switch (numDivisible % 2) {
		case 0:
			System.out.println("El numero " + numDivisible + " es divisible por 2");
			break;

		default:
			System.out.println("El numero " + numDivisible + " no es divisible por 2");
			break;
		}
		
		switch (numDivisible % 3) {
		case 0:
			System.out.println("El numero " + numDivisible + " es divisible por 3");
			break;

		default:
			System.out.println("El numero " + numDivisible + " no es divisible por 3");
			break;
		}
		
		switch (numDivisible % 5) {
		case 0:
			System.out.println("El numero " + numDivisible + " es divisible por 5");
			break;

		default:
			System.out.println("El numero " + numDivisible + " no es divisible por 5");
			break;
		}
		
		// Ejercicio 4
		char estado = 'C';
		
		switch (estado) {
		case 's':
		case 'S':	
			System.out.println("Soltero");
			break;

		
		case 'c':
		case 'C':	
			System.out.println("Casado");
			break;

		case 'v':
		case 'V':	
			System.out.println("Viudo");
			break;

		case 'd':
		case 'D':	
			System.out.println("Divorciado");
			break;
			
		case 'p':
		case 'P':	
			System.out.println("Pareja de hecho");
			break;

		
		default:
			System.out.println("Estado civil desconocido");
			break;
		}
		
		
		// Ejercicio 5
		char letra = 'I';
		
		
		switch (letra) {
		case 'I':
		case 'i':
			System.out.println("1");
			break;

		case 'V':
		case 'v':
			System.out.println("5");
			break;
			
		case 'X':
		case 'x':
			System.out.println("10");
			break;

		case 'L':
		case 'l':
			System.out.println("50");
			break;

		case 'C':
		case 'c':
			System.out.println("100");
			break;

		case 'D':
		case 'd':
			System.out.println("500");
			break;

		case 'M':
		case 'm':
			System.out.println("1000");
			break;

		default:
			System.out.println("No se reconoce como numero romano");
			break;
		}

	}

}
