package es.cfc.models;

// Crear una plantilla para todos mis clientes
public class Cliente {

	// propiedades o caracteristicas de nuestros clientes
	// declarar variables
	public String nombre;
	public String cif;
	public double cifraVentas;
	public boolean esVip;

	// metodos o acciones del cliente
	public void mostrarInfo() {
		System.out.println(
				"Nombre: " + nombre + " CIF: " + cif + " Cifra de ventas: " + cifraVentas + 
				" Es VIP? " + esVip);
	}
}
