package es.cfc.main;

// cuando necesito un recurso que esta declarado en otro paquete, lo tengo que importar
import es.cfc.models.Cliente;

public class AppMain {

	public static void main(String[] args) {
		
		// Crear instancias o Objetos de Cliente
		int numero = 5;
		
		Cliente cliente1 = new Cliente();
		
		// Damos valores a mi nuevo objeto cliente1
		cliente1.nombre = "Transportes Lopez, S.L.";
		cliente1.cif = "B-12345678";
		cliente1.cifraVentas = 750000.78;
		cliente1.esVip = true;
		
		Cliente cliente2 = new Cliente();
		cliente2.nombre = "Fruteria Alonso, S.A.";
		cliente2.cif = "B-98765432";
		cliente2.cifraVentas = 5649.56;
		cliente2.esVip = false;
		
		System.out.println(cliente1);
		System.out.println(cliente2);
		
		cliente1.mostrarInfo();
		cliente2.mostrarInfo();
		
	}
}
