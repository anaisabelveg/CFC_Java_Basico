package es.cfc.models;

public class Vehiculo {

	private int combustible;
	private char tipo; // T terrestre, A aereo, M maritimo
	private boolean pasadoITV;

	public Vehiculo() {
		// TODO Auto-generated constructor stub
	}

	public Vehiculo(int combustible, char tipo, boolean pasadoITV) {
		super();
		this.combustible = combustible;
		this.tipo = tipo;
		this.pasadoITV = pasadoITV;
	}

	public void arrancar() {
		System.out.println("El vehiculo esta arrancando");
	}

	public void parar() {
		System.out.println("El vehiculo esta parado");
	}

	public void repostar() {
		System.out.println("El vehiculo está repostando");
	}

	public int getCombustible() {
		return combustible;
	}

	public void setCombustible(int combustible) {
		this.combustible = combustible;
	}

	public char getTipo() {
		return tipo;
	}

	public void setTipo(char tipo) {
		this.tipo = tipo;
	}

	public boolean isPasadoITV() {
		return pasadoITV;
	}

	public void setPasadoITV(boolean pasadoITV) {
		this.pasadoITV = pasadoITV;
	}

	@Override
	public String toString() {
		return "combustible=" + combustible + ", tipo=" + tipo + 
				", pasadoITV=" + pasadoITV + " ";
	}
	
	

}
