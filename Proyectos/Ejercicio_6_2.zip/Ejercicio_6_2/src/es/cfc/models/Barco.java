package es.cfc.models;

public class Barco extends Vehiculo{
	
	private int anyoBotadura;
	
	public Barco() {
		// TODO Auto-generated constructor stub
	}
	
	
	public Barco(int combustible, char tipo, boolean pasadoITV, int anyoBotadura) {
		super(combustible, tipo, pasadoITV);
		this.anyoBotadura = anyoBotadura;
	}


	@Override
	public void arrancar() {
		// TODO Auto-generated method stub
		System.out.println("El barco esta zarpando");
	}
	
	@Override
	public void parar() {
		// TODO Auto-generated method stub
		System.out.println("El barco esta atracando");
	}
	
	public int getAnyoBotadura() {
		return anyoBotadura;
	}
	
	public void setAnyoBotadura(int anyoBotadura) {
		this.anyoBotadura = anyoBotadura;
	}

	@Override
	public String toString() {
		return super.toString() + "anyoBotadura=" + anyoBotadura + " ";
	}
	
	
}
