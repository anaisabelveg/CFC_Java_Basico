package es.cfc.models;

public class Tren extends Vehiculo {

	private boolean ave;

	public Tren() {
		// TODO Auto-generated constructor stub
	}

	public Tren(int combustible, char tipo, boolean pasadoITV, boolean ave) {
		super(combustible, tipo, pasadoITV);
		this.ave = ave;
	}
	
	@Override
	public void arrancar() {
		// TODO Auto-generated method stub
		System.out.println("El tren sale de la estacion");
	}
	
	@Override
	public void parar() {
		// TODO Auto-generated method stub
		System.out.println("El tren entra en la estacion");
	}

	public boolean isAve() {
		return ave;
	}

	public void setAve(boolean ave) {
		this.ave = ave;
	}

	@Override
	public String toString() {
		return super.toString() + "ave=" + ave + " ";
	}

}
