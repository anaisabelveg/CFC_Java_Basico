package es.cfc.models;

public class Coche extends Vehiculo {

	private int numPlazas;

	public Coche() {
		// TODO Auto-generated constructor stub
	}

	public Coche(int combustible, char tipo, boolean pasadoITV, int numPlazas) {
		super(combustible, tipo, pasadoITV);
		this.numPlazas = numPlazas;
	}

	public int getNumPlazas() {
		return numPlazas;
	}

	public void setNumPlazas(int numPlazas) {
		this.numPlazas = numPlazas;
	}

	@Override
	public String toString() {
		return super.toString() + "numPlazas=" + numPlazas +  " ";
	}
	
	

}
