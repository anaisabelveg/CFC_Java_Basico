package es.cfc.models;

public class Avion extends Vehiculo {

	private int pasajeros;
	private String aerolinea;

	public Avion() {
		super();
	}

	public Avion(int combustible, char tipo, boolean pasadoITV, int pasajeros, String aerolinea) {
		super(combustible, tipo, pasadoITV);
		this.pasajeros = pasajeros;
		this.aerolinea = aerolinea;
	}

	@Override
	public void arrancar() {
		System.out.println("El avion esta despegando");
	}

	@Override
	public void parar() {
		System.out.println("El avion aterriza");
	}

	@Override
	public void repostar() {
		System.out.println("El avion esta repostando");
	}

	public int getPasajeros() {
		return pasajeros;
	}

	public void setPasajeros(int pasajeros) {
		this.pasajeros = pasajeros;
	}

	public String getAerolinea() {
		return aerolinea;
	}

	public void setAerolinea(String aerolinea) {
		this.aerolinea = aerolinea;
	}

	@Override
	public String toString() {
		return super.toString() + "pasajeros=" + pasajeros + ", aerolinea=" + aerolinea + " ";
	}

}
