package es.cfc.main;



import es.cfc.models.Avion;
import es.cfc.models.Barco;
import es.cfc.models.Coche;
import es.cfc.models.Tren;
import es.cfc.models.Vehiculo;

public class TestVehiculos {

	public static void main(String[] args) {
		Vehiculo vehiculo = new Vehiculo(80, 'T', true);
		Coche coche = new Coche(100, 'T', false, 5);
		Barco barco = new Barco(5000, 'M', true, 2019);
		Tren tren = new Tren(800, 'T', true, false);
		Avion avion = new Avion(10000, 'A', true, 450, "Iberia");
		
		System.out.println(vehiculo);
		vehiculo.repostar();
		vehiculo.arrancar();
		vehiculo.parar();
		System.out.println("------------------------------");
		
		System.out.println(coche);
		coche.repostar();
		coche.arrancar();
		coche.parar();
		System.out.println("------------------------------");
		
		System.out.println(barco);
		barco.repostar();
		barco.arrancar();
		barco.parar();
		System.out.println("------------------------------");
		
		System.out.println(tren);
		tren.repostar();
		tren.arrancar();
		tren.parar();
		System.out.println("------------------------------");
		
		System.out.println(avion);
		avion.repostar();
		avion.arrancar();
		avion.parar();
		System.out.println("------------------------------");

	}

}
