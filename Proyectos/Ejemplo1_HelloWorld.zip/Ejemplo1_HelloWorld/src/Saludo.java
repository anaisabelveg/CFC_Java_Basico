
public class Saludo {

	// Puerta de entrada a la aplicacion
	public static void main(String[] args) {
		
		// Declarar una variable
		// tipo nombre_variable = valor;
		String nombre = "Pepito";
		int edad = 23;
		
		System.out.println("Bienvenidos al curso de Java");
		
		// Usar las variables
		System.out.println("Me llamo " + nombre + " y tengo " + edad + " años");
	}

}
