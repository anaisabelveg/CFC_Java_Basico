package vegas.anabel.models;

public class Animal {
	
	// propiedades
	public String nombre;
	public String familia;
	public String especie;
	public float peso;
	public boolean mascota;
	

	// metodos
	public void comer() {
		System.out.println("Esta comiendo");
	}
	
	public void dormir() {
		System.out.println("Esta durmiendo");
	}
	
	public void cambiarPeso(float nuevoPeso) {
		peso = nuevoPeso;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public void mostrarInfo(){
		System.out.println("Nombre: " + nombre + " Familia: " + familia +
				" Especie: " + especie + " Peso: " + peso + " Mascota: " + mascota);
	}
}
