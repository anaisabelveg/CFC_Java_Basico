package vegas.anabel.main;

import vegas.anabel.models.Animal;

public class TestAnimal {

	public static void main(String[] args) {
		
		Animal perro = new Animal();
		perro.nombre = "Fifi";
		perro.familia = "Perro";
		perro.especie = "Perdiguero";
		perro.peso = 14;
		perro.mascota = true;
		
		Animal pez = new Animal();
		pez.nombre = "Nemo";
		pez.familia = "Peces";
		pez.especie = "Payaso";
		pez.peso = 0.4F;
		pez.mascota = true;
		
		Animal cocodrilo = new Animal();
		cocodrilo.nombre = "Caries";
		cocodrilo.familia = "Reptil";
		cocodrilo.especie = "Caiman";
		cocodrilo.peso = 120;
		cocodrilo.mascota = false;
		
		System.out.println("Nombre del pez: " + pez.getNombre());
		
		// Engordar al cocodrilo
		cocodrilo.cambiarPeso(140);
		
		perro.comer();
		perro.dormir();
		
		// mostrar la info de cada uno
		perro.mostrarInfo();
		pez.mostrarInfo();
		cocodrilo.mostrarInfo();

	}

}
