package es.cfc.main;

import es.cfc.models.EstadoCivil;
import es.cfc.models.EstadoCivilAvanzado;
import es.cfc.models.Persona;

public class AppMain {

	public static void main(String[] args) {
		Persona p1 = new Persona("Maria", 28, EstadoCivilAvanzado.SOLTERO);
		Persona p2 = new Persona("Pedro", 69, EstadoCivilAvanzado.VIUDO);
		Persona p3 = new Persona("Luis", 54, EstadoCivilAvanzado.DIVORCIADO);
		
		System.out.println(p1);
		System.out.println(p2);
		System.out.println(p3);
		
		System.out.println(p1.getEstadoCivil());
		System.out.println(p1.getEstadoCivil().getLetra());

	}

}
