package es.cfc.models;

public enum EstadoCivilAvanzado {
	
	// Todos los valores de un tipo enumerado se entiende
	// que son constantes: static y final
	SOLTERO('S'), 
	CASADO('C'), 
	VIUDO('V'), 
	DIVORCIADO('D'), 
	PAREJA_HECHO('P');
	
	private char letra;
	
	// el constructor de un tipo enumerado, debe ser private
	private EstadoCivilAvanzado(char letra) {
		this.letra = letra;
	}
	
	public char getLetra() {
		return letra;
	}
}
