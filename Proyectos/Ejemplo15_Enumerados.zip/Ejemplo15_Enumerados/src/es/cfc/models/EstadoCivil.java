package es.cfc.models;

public enum EstadoCivil {
	
	// Todos los valores de un tipo enumerado se entiende
	// que son constantes: static y final
	SOLTERO, CASADO, VIUDO, DIVORCIADO, PAREJA_HECHO;

}
