package es.cfc;

public class AppMain {

	public static void main(String[] args) {
		
		int numero = 8;
		
		// Clases envolventes, wrapper
		/*
		 * int -> Integer
		 * char -> Character
		 * boolean -> Boolean
		 * short -> Short
		 * byte -> Byte
		 * long -> Long
		 * double -> Double
		 * float -> Float
		 * */
		
		// Convertir numero a objeto Integer
		// primitivo -> objeto  (Boxing)
		Integer objInteger = Integer.valueOf(numero);
		Integer objInteger2 = new Integer(numero);
		
		// Convertir el objeto a tipo primitivo
		// objeto -> primitivo (Unboxing)
		numero = objInteger.intValue();
		
		// A partir de java 5 podemos hacer autoboxing
		Integer numero2 = 6;
		Integer numero3 = numero;
		int numero4 = objInteger;
		
		// Ejemplos de uso
		System.out.println("Maximo 8 y 5: " + Integer.max(8, 5));
		System.out.println("H es una letra? " + Character.isLetter('h'));
		System.out.println("H es un numero? " + Character.isDigit('h'));
		System.out.println("182 en hexadecimal " + Integer.toHexString(182));
		System.out.println("182 en binario " + Integer.toBinaryString(182));
		System.out.println("182 en octal " + Integer.toOctalString(182));
	}

}
