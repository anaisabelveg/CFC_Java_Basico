package vegas.anabel.business;

public class Calculadora {
	
	public double sumar(double n1, double n2) {
		double resultado = n1 + n2;
		return resultado;
	}
	
	public double restar(double n1, double n2) {
		return n1 - n2;
	}
	
	public double multiplicar(double n1, double n2) {
		return n1 * n2;
	}
	
	public double dividir(double n1, double n2) {
		return n1 / n2;
	}
	
	public double restoDivision(double n1, double n2) {
		return n1 % n2;
	}

}
