package vegas.anabel.main;

import vegas.anabel.business.Calculadora;

public class Principal {

	public static void main(String[] args) {
		
		// Crear un objeto de la clase Calculadora
		Calculadora calcu = new Calculadora();
		
		// Sumar 7 y 25
		int numero1 = 7;
		int numero2 = 25;
		System.out.println(calcu.sumar(numero1, numero2));
		//System.out.println(calcu.sumar(7, 25));
		
		System.out.println(calcu.restar(25, 7));
		
		// multiplicar
		System.out.println(calcu.multiplicar(25, 7));
		
		// dividir
		System.out.println(calcu.dividir(25, 7));

	}

}
