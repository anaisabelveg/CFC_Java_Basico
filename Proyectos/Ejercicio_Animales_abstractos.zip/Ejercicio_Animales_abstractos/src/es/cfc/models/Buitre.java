package es.cfc.models;

public class Buitre extends Pajaro{

}
