package es.cfc.models;

public class Pajaro extends Animal{
	
	@Override
	public void comer() {
		// TODO Auto-generated method stub
		System.out.println("El pajaro come");
	}
	
	@Override
	public void moverse() {
		// TODO Auto-generated method stub
		System.out.println("El pajaro vuela");
	}

}
