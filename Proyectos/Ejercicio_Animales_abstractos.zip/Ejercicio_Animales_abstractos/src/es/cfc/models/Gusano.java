package es.cfc.models;

public class Gusano extends Animal{
	
	@Override
	public void comer() {
		// TODO Auto-generated method stub
		System.out.println("El gusano come");
	}
	
	@Override
	public void moverse() {
		// TODO Auto-generated method stub
		System.out.println("El gusano se arrastra");
	}

}
