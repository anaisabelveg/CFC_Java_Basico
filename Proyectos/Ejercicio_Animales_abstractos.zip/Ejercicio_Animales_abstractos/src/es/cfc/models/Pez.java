package es.cfc.models;

public class Pez extends Animal{

	@Override
	public void comer() {
		// TODO Auto-generated method stub
		System.out.println("El pez come");
	}

	@Override
	public void moverse() {
		// TODO Auto-generated method stub
		System.out.println("El pez nada");
	}

}
