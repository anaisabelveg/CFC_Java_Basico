package es.cfc.models;

public class Gorrion extends Pajaro{

}
