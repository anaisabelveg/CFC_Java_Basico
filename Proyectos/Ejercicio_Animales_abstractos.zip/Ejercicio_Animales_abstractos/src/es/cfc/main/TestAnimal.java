package es.cfc.main;

import es.cfc.models.Animal;
import es.cfc.models.Gorrion;
import es.cfc.models.Gusano;
import es.cfc.models.Pajaro;
import es.cfc.models.Perro;

public class TestAnimal {

	public static void main(String[] args) {
		
		Object object = new Perro();
		Animal gusano = new Gusano();
		Pajaro gorrion = new Gorrion();
		
		gusano.comer();
		gorrion.moverse();

	}

}
