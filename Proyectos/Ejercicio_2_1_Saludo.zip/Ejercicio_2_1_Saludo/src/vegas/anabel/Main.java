package vegas.anabel;

public class Main {

	public static void main(String[] args) {
		
		Saludo saludo = new Saludo();
		saludo.saludar();

	}

}
