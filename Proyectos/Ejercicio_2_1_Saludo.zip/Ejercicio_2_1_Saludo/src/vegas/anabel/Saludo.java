package vegas.anabel;

public class Saludo {
	
	public void saludar() {
		System.out.println("Bienvenido al curso Java");
	}

}
