package es.cfc.main;

public class Ejercicio9 {

	public static void main(String[] args) {

		// Version 1 con break
//		for (int numero = 1; numero <= 100; numero++) {
//			System.out.println("Probando numero " + numero);
//			
//			// doy por hecho que todos los numeros son primos salvo
//			// que se demuestre lo contrario
//			boolean esPrimo = true;
//			
//			for (int divisor = 2; divisor < numero; divisor++) {
//				System.out.println("Buscando divisor " + divisor);
//				if (numero % divisor == 0) {
//					// El numero ya no es primo
//					esPrimo = false;
//					
//					// si he encontrado un divisor no continuo buscando divisores
//					break;
//				}
//			}
//			
//			if (esPrimo) {
//				System.out.println(numero);
//			}
//		}

		// Version 2 con continue
		
		bucle_numeros:
		for (int numero = 1; numero <= 100; numero++) {
			System.out.println("Probando numero " + numero);

			// doy por hecho que todos los numeros son primos salvo
			// que se demuestre lo contrario
			boolean esPrimo = true;

			for (int divisor = 2; divisor < numero; divisor++) {
				System.out.println("Buscando divisor " + divisor);
				if (numero % divisor == 0) {
					// El numero ya no es primo
					esPrimo = false;

					// si no es primo paso al siguiente numero
					continue bucle_numeros;
				}
			}

			if (esPrimo) {
				System.out.println(numero);
			}
		}

	}

}
