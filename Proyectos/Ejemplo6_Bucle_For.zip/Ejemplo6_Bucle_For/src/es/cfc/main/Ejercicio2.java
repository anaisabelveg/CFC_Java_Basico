package es.cfc.main;

public class Ejercicio2 {

	public static void main(String[] args) {
	
		for (int anyo = 1990; anyo <= 2007; anyo++) {
			System.out.println("Feliz Navidad " + anyo);
		}

	}

}
