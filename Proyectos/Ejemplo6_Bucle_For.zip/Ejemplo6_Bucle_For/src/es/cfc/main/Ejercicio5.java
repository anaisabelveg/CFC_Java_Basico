package es.cfc.main;

public class Ejercicio5 {

	public static void main(String[] args) {
		
		int numero = 2;
		
		for(int i=8; i>1; i--) {
			//numero = numero * 2;
			numero *= 2;
		}

		System.out.println("2 elevado a 8 " + numero);
		System.out.println(Math.pow(2, 8));
	}

}
