package es.cfc.main;

public class Ejercicio6 {
	
	public static void main(String[] args) {
		
		for (int num = 30; num > 0; num--) {
			if (num % 2 != 0) {
				System.out.println(num);
			}
		}
	}

}
