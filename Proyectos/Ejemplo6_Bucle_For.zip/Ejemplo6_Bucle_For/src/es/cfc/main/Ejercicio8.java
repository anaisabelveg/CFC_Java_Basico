package es.cfc.main;

public class Ejercicio8 {

	public static void main(String[] args) {
		
		for (int num = 1; num <= 20; num++) {
			
			System.out.println(num + " -->");
			
			for(int i=1; i<= num; i++) {
				if (num % i == 0) {
					System.out.println("es divisible por " + i);
				}
			}
		}

	}

}
