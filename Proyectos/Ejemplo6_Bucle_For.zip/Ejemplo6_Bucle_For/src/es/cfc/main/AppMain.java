package es.cfc.main;

public class AppMain {

	public static void main(String[] args) {
		// Ejemplo 1
		// Mostrar los numeros del 1 al 10
		
		for(int i = 1; i <= 10; i++) {
			System.out.println(i);
		}
		System.out.println("------------ FIN ------------");
		
		// Ejemplo 2
		// Mostrar los numeros del 10 al 1
		
		for(int i = 10; i >= 1; i--) {
			System.out.println(i);
		}
		System.out.println("------------ FIN ------------");
		
		// Ejemplo 3
		// Mostrar los numeros del 1 al 10 pero de 2 en 2
		// i = i + 2     i+=2
		// i = i * 3     i*=3
		// i = i % 2     i%=2
		for(int i = 1; i <= 10; i+=2) {
			System.out.println(i);
		}
		System.out.println("------------ FIN ------------");
		
		// Ejemplo 4
		// Mostrar los numeros del 1 al 10 pero SOLO si son multiplos de 5
		for(int i = 1; i <= 10; i++) {
			if (i % 5 == 0) {
				System.out.println(i);
			}
		}
		
		// Ejemplo 5
		for (int tabla=1; tabla<=10; tabla++) {
			System.out.println("Tabla del numero " + tabla);
			System.out.println("-------------------");
			
			for (int i=1; i<= 10; i++) {
				System.out.println(tabla + " x " + i + " = " + (tabla*i));
			}
			
			System.out.println();
			
			
		}
		
		Math.sqrt(9);

	}

}
