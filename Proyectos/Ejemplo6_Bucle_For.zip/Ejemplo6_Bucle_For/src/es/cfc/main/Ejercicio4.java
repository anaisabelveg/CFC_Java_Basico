package es.cfc.main;

public class Ejercicio4 {

	public static void main(String[] args) {
		
		long resultado = 1;
		
		for (int numero = 15; numero > 1; numero--) {
			//resultado = resultado * numero;
			resultado *= numero;
		}
		
		System.out.println("15! = " + resultado);
		
	}
}
