package es.cfc;

public class AppMain {

	public static void main(String[] args) {
		
		String cadena = "Bienvenidos al curso de Java";
		
		// Mostrar la cadena en mayusculas
		System.out.println(cadena.toUpperCase());
		
		// Mostrar la cadena en minusculas
		System.out.println(cadena.toLowerCase());
		
		// Mostrar la palabra Bienvenidos
		System.out.println(cadena.substring(0, cadena.indexOf(" ")));
		
		// Mostrar la palabra Java
		System.out.println(cadena.substring(cadena.lastIndexOf(" ") + 1));
		
		// Mostrar la palabra curso
		System.out.println(cadena.substring(cadena.indexOf("c"), 
				cadena.indexOf(" ", cadena.indexOf("c"))));
		
		// Mostrar la posicion de la letra c
		System.out.println(cadena.indexOf('c'));
		
		// Mostrar la longitud de la cadena
		System.out.println(cadena.length());
		
		// Modificar las e por E
		System.out.println(cadena.replaceAll("e", "E"));
		
		// Concatenar la frase anterior con " con fecha 14 de Septiembre";
		System.out.println(cadena.concat(" con fecha 14 de Septiembre"));
	}

}
