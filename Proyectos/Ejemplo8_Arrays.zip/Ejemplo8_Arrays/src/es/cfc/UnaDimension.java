package es.cfc;

import es.cfc.models.Empleado;

public class UnaDimension {

	public static void main(String[] args) {
		
		// Declarar una variable de tipo array
		int numeros[];
		
		// Crear el array
		numeros = new int[4]; // 4 es la longitud del array
		
		// Guardar valores en el array
		// los indices del array van de 0 a longitud-1
		numeros[0] = 8;
		numeros[1] = 3;
		numeros[2] = 5;
		numeros[3] = 7;
		
		// Todo en uno
		int numeros2[] = {8,3,5,7};
		int numeros3[] = new int[] {8,3,5,7};
		
		System.out.println("Valor primero " + numeros[0]);
		
		// recorrer un array
		// con bucle for
		for (int indice = 0; indice < numeros.length; indice++) {
			System.out.println(numeros[indice]);
		}
		
		
		// con bucle for-each
		for (int num  : numeros) {
			System.out.println(num);
		}
		
		/*****************************  ARRAYS CON OBJETOS ****************************/
		
		Empleado empleados[] = new Empleado[3];
		empleados[0] = new Empleado("Maria", 25000, 31);
		empleados[1] = new Empleado("Juan", 50000, 52);
		empleados[2] = new Empleado("Perico", 37000, 43);
		
		// Sueldo de Perico
		System.out.println("Sueldo de Perico: " + empleados[2].sueldo);
		
		// Todo en uno
		Empleado empleados2[] = {
				new Empleado("Maria", 25000, 31),
				new Empleado("Juan", 50000, 52),
				new Empleado("Perico", 37000, 43)
		};
		
		for (Empleado empleado : empleados2) {
			empleado.mostrarInfo();
		}
		

	}

}
