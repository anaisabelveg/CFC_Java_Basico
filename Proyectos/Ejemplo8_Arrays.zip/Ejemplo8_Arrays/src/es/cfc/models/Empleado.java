package es.cfc.models;

public class Empleado {
	
	public String nombre;
	public double sueldo;
	public int edad;
	
	// Cuando el compilador compilar la clase mira si hay algun constructor
	// declarado, si no lo hay agrega el constructor por defecto
	public Empleado() {
		// TODO Auto-generated constructor stub
	}
	
	// sobrecarga de constructores
	public Empleado(String nombre, double sueldo, int edad) {
		super();
		this.nombre = nombre;
		this.sueldo = sueldo;
		this.edad = edad;
	}
	
	public void mostrarInfo() {
		System.out.println("Nombre: " + nombre + " Sueldo: " + sueldo + " Edad: " + edad );
	}

}
