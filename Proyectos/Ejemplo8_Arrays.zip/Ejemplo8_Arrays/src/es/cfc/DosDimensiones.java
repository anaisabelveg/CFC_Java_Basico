package es.cfc;

import java.util.Arrays;

public class DosDimensiones {

	public static void main(String[] args) {
		
		// Declarar una variable de tipo array
		int numeros[][];
		
		// Crear el array
		numeros = new int[2][2];  // 2 filas x 2 columnas
		
		// Asignar valores
		numeros[0][0] = 7;
		numeros[0][1] = 6;
		numeros[1][0] = 2;
		numeros[1][1] = 4;
		
		// Matriz no cuadrada
		int numeros2[][] = new int[3][];  // 3 filas pero las columnas estan por definir
		
		// Crear los arrays de las columnas
		numeros2[0] = new int[2];
		numeros2[1] = new int[4];
		numeros2[2] = new int[3];
		
		numeros2[0][0] = 9;
		numeros2[0][1] = 8;
		numeros2[1][0] = 7;
		numeros2[1][1] = 6;
		numeros2[1][2] = 5;
		numeros2[1][3] = 4;
		numeros2[2][0] = 3;
		numeros2[2][1] = 2;
		numeros2[2][2] = 1;
		
		System.out.println(Arrays.deepToString(numeros));
		System.out.println(Arrays.deepToString(numeros2));
		
		// Todo en uno
		int numeros3[][] = { {7,6}, {2,4} };  // {fila, fila}
		int numeros4[][] = new int[][] { {9,8}, {7,6,5,4}, {3,2,1}};
		
		System.out.println(Arrays.deepToString(numeros3));
		System.out.println(Arrays.deepToString(numeros4));
		
		
		
		// Recorrer el array con for tradicional
		for (int fila = 0; fila < numeros4.length; fila++) {
			for (int columna = 0; columna < numeros4[fila].length; columna++) {
				System.out.print(numeros4[fila][columna] + "\t");
			}
			System.out.println();
		}
		
		// Recorrer el array con for-each
		for (int[] columnas : numeros4) {
			for (int numero : columnas) {
				System.out.print(numero + " ");
			}
			System.out.println();
		}
		
		// crear una matriz 3x3 y sumar los numeros de la diagonal principal
		int matriz[][] = {{5,7,2},{4,1,8},{3,6,9}};
		
		System.out.println(Arrays.deepToString(matriz));
		
		int resultado = 0;
		for(int fila = 0; fila < matriz.length; fila++) {
			for(int columna = 0; columna < matriz[fila].length; columna++) {
				if (fila == columna) {
					resultado += matriz[fila][columna];
				}
			}
		}
		
		System.out.println("Suma de diagonal: " + resultado);
		
		resultado = 0;
		for(int fila = 0; fila < matriz.length; fila++) {
			resultado += matriz[fila][fila];
		}
		
		System.out.println("Suma de diagonal: " + resultado);

	}

}





