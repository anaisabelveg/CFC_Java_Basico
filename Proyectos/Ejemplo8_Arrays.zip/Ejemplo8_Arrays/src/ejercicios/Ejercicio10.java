package ejercicios;

public class Ejercicio10 {

	public static void main(String[] args) {
		// Mostrar una matriz segun formato
		
		int[][] numeros = new int[][] {
			{3,4,5,78},
			{0,0,0,0},
			{1,1,1,1},
			{6,6,6,-1}};
			
		for (int[] columnas : numeros) {
			
			System.out.print("{");
			for (int num : columnas) {
				System.out.print(num + " ");
			}
			System.out.println("}");
		}	

	}

}
