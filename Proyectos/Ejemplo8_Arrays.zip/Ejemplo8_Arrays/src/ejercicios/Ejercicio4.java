package ejercicios;

import java.util.Arrays;

public class Ejercicio4 {

	public static void main(String[] args) {
		// Juntar 2 arrays en un tercero. 
		// Primero los elementos de uno y luego los del otro
		
		int[] array1 = new int[] {1,2,3,4,5};
		int[] array2 = new int[] {334,23,4};
		
		// Crear un array con tamaño de la suma de ambos arrays
		int[] array3 = new int[array1.length + array2.length];
		
		// Copiar los elementos de array1 en array3
		System.arraycopy(array1, 0, array3, 0, array1.length);
		
		// Copiar los elementos de array2 en array3
		System.arraycopy(array2, 0, array3, array1.length, array2.length);
		
		System.out.println(array3);
		System.out.println(Arrays.toString(array3));
		
		
		// Crear un array con tamaño de la suma de ambos arrays
		array3 = new int[array1.length + array2.length];
		
		int posicionArray = 0;
		for(int i=0; i < array1.length; i++) {
			array3[posicionArray] = array1[i];
			posicionArray++;
		}
		
		for(int i=0; i < array2.length; i++) {
			array3[posicionArray] = array2[i];
			posicionArray++;
		}
		
		System.out.println(Arrays.toString(array3));
		
	}

}



