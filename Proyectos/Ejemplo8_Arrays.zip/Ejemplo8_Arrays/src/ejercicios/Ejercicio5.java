package ejercicios;

import java.util.Arrays;

public class Ejercicio5 {

	public static void main(String[] args) {
		// Mezclar 2 arrays
		
		char[] cars1 = new char[] {'1','2','3','4','5','6'};
		char[] cars2 = new char[] {'a','e','r','t','y','u'};
		
		// Crear el array con la suma de las dos longitudes
		char[] result = new char[cars1.length + cars2.length];
		
		
		// 0,1,2,3,4,5
		int posicion = 0;
		for (int i=0; i<cars1.length; i++) {
			result[posicion] = cars1[i];
			posicion++;
			result[posicion] = cars2[i];
			posicion++;
		}
		
		System.out.println(Arrays.toString(result));
		
		result = new char[cars1.length + cars2.length];
		
		int posicionArray1 = 0;
		int posicionArray2 = 0;
		int posicionArray3 = 0;
		
		while( posicionArray3 < result.length) {
			if (posicionArray1 < cars1.length) {
				result[posicionArray3] = cars1[posicionArray1];
				posicionArray1++;
				posicionArray3++;
			}
			
			if (posicionArray2 < cars2.length) {
				result[posicionArray3] = cars2[posicionArray2];
				posicionArray2++;
				posicionArray3++;
			}
		}
		
		System.out.println(Arrays.toString(result));

	}

}











