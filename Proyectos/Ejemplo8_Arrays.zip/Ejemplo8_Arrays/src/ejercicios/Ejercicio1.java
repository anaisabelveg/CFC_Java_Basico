package ejercicios;

public class Ejercicio1 {

	public static void main(String[] args) {
		// En un array de caracteres pintar solo las vocales
		
		char[] caracteres = new char[] {'w','f','a','h','u','g','b','i','o'};
		
		for (char dato : caracteres) {
			
			// Convertirlo a minuscula
			Character letra = Character.toLowerCase(dato);

			if ((letra == 'a') || (letra == 'e') || (letra == 'i') || 
					(letra == 'o') || (letra == 'u')){
				System.out.println(letra);
			}
			
			switch (letra) {
			case 'a':
			case 'e':
			case 'i':
			case 'o':
			case 'u':
				System.out.println(letra);
				break;
			}
		}

	}

}
