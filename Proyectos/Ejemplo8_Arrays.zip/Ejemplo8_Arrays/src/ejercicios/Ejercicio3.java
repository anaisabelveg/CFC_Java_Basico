package ejercicios;

public class Ejercicio3 {

	public static void main(String[] args) {
		// Mostrar los elementos de un array de forma inversa
		
		String nombres[] = {"Juan", "Pedro", "Luis", "Maria", "Laura", "Pascual"};
		
		for(int i = nombres.length -1; i >= 0; i--) {
			System.out.println(nombres[i]);
		}

	}

}
