package ejercicios;

public class Ejercicio7 {
	
	public static void main(String[] args) {
		// sumar las componentes del array
		
		float[] decimales = new float[] {3.4F, 5.67F, 12.0F, 3.141615F, 0.0F};
		
		float suma = 0;
		
		for (float numero : decimales) {
			suma += numero;
		}
		
		System.out.println("Suma: " + suma);
	}

}
