package ejercicios;

public class Ejercicio2 {

	public static void main(String[] args) {
		// con un array de enteros mostrar pares, impares y multiplos de 3
		int [] enteros = {1,9,5,4,8,12,2,7};
		
		for (int numero : enteros) {
			if (numero % 2 == 0) {
				System.out.println("El numero " + numero + " es par");
			} else {
				System.out.println("El numero " + numero + " es impar");
			}
			
			if (numero % 3 == 0) {
				System.out.println("El numero " + numero + " es multiplo de 3");
			} else {
				System.out.println("El numero " + numero + " no es multiplo de 3");
			}
		}

	}

}
