package vegas.anabel.main;

import vegas.anabel.business.Persona;

public class TestPersona {

	public static void main(String[] args) {
		
		Persona persona = new Persona();
		
		// Calcular la edad en dias y segundos de varias personas
		System.out.println("24 años en dias " + persona.edadDias(24));
		System.out.println("24 años en segundos " + persona.edadSegundos(24));
		
		System.out.println("140 años en dias " + persona.edadDias(140));
		System.out.println("140 años en segundos " + persona.edadSegundos(140));
		
		int numero = 7;
		numero++;
		System.out.println(numero);
		
		numero--;
		System.out.println(numero);

	}

}
