package vegas.anabel.business;

public class Persona {
	
	public int edadDias(int edad) {
		return edad * 365;
	}
	
	public long edadSegundos(int edad) {
		return edad * 365 * 24 * 60 * 60L;
	}

}
