package es.cfc.main;

import es.cfc.models.Jefe;

public class AppMain {

	public static void main(String[] args) {
		
		Jefe jefe = new Jefe();
		jefe.setNombre("Pedro");
		jefe.setEdad(39);
		jefe.setSexo('H');
		jefe.setSueldo(47_000);
		jefe.setBonus(10_000);
		jefe.setCoche("1234-LVH");
		
		Jefe jefe2 = new Jefe("Pedro", 39, 'H', 47_000, 10_000, "1234-LVH");
		
		System.out.println(jefe);
		
		// Cuando mostramos un objeto por consola, llama al metodo toString()
		//System.out.println(jefe.toString());

	}

}
