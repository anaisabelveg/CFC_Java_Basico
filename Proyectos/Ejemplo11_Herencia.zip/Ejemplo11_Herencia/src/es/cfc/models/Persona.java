package es.cfc.models;


// Cuando se compila clase, si no hereda de ninguna clase, 
// el compilador añade extends Object
// public class Persona extends Object
public class Persona {

	// modos de acceso en UML
	// + public, - private, # protected, ~ default

	private String nombre;
	private int edad;
	private char sexo;

	// Es recomendable mantener el constructor por defecto, sin argumentos
	public Persona() {
		// TODO Auto-generated constructor stub
	}

	public Persona(String nombre, int edad, char sexo) {
		// Se invoca al constructor de la clase Object
		super();
		this.nombre = nombre;
		this.edad = edad;
		this.sexo = sexo;
	}
	
	@Override
	public String toString() {
		return "nombre=" + nombre + ", edad=" + edad + ", sexo=" + sexo + " ";
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public char getSexo() {
		return sexo;
	}

	public void setSexo(char sexo) {
		this.sexo = sexo;
	}

}
