package es.cfc.models;

public class Empleado extends Persona {

	private double sueldo;

	public Empleado() {
		// Llama al constructor por defecto de Persona
		super();
	}
	
	public Empleado(String nombre, int edad, char sexo, double sueldo) {
		// Invocar al constructor de la superclase
		// super() se utiliza SOLO en el constructor,
		// debe estar en la primera linea
		super(nombre, edad, sexo);
		this.sueldo = sueldo;
	}
	

	@Override
	public String toString() {
		return super.toString() + "sueldo=" + sueldo  + " ";
	}

	public double getSueldo() {
		return sueldo;
	}

	public void setSueldo(double sueldo) {
		this.sueldo = sueldo;
	}

}
