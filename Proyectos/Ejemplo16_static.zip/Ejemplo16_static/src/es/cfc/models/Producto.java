package es.cfc.models;

public class Producto {
	
	// Propiedades del objeto
	// Variables de instancia; existe una copia por cada instancia
	private int id;
	private String descripcion;
	private double precio;
	
	// Variable de clase; existe una sola copia y reside en la clase
	private static int contador;
	
	public Producto() {
		contador++;
	}

	public Producto(int id, String descripcion, double precio) {
		super();
		this.id = id;
		this.descripcion = descripcion;
		this.precio = precio;
		contador++;
	}
	
	public static int getContador() {
		return contador;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}
	
	

}
