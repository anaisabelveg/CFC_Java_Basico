package es.cfc.main;

import es.cfc.models.Producto;

public class AppMain {

	public static void main(String[] args) {
		
		Producto pantalla = new Producto(1, "Pantalla 17 pulgadas", 145.90);
		Producto teclado = new Producto(2, "Teclado inalambrico", 29.95);
		
		System.out.println("Cuantos productos tengo? " + teclado.getContador());
		
		// Clase.recurso_static
		System.out.println("Cuantos productos tengo? " + Producto.getContador());

	}

}
