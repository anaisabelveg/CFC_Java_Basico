package es.cfc.business;

public class MiClase {
	
	public void metodoPublic() {
		System.out.println("Metodo publico");
	}
	
	private void metodoPrivate() {
		System.out.println("Metodo private");
	}
	
	protected void metodoProtected() {
		System.out.println("Metodo protected");
	}
	
	void metodoDefault() {
		System.out.println("Metodo default");
	}

}
