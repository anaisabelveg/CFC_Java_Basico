package es.cfc.business;

public class SubClase extends MiClase{
	
	public void prueba() {
		
		// Puedo acceder al metodo publico porque se puede
		// desde cualquier paquete
		metodoPublic();
		
		
		// Puedo acceder por 2 razones:
		// 1.- Estamos en la subclase, por herencia
		// 2.- MiClase y SubClase estan en el mismo paquete
		metodoProtected();
		
		// Porque esta en el mismo paquete
		metodoDefault();
	}

}
