package es.cfc.main;

import es.cfc.business.MiClase;

public class AppMain {

	public static void main(String[] args) {
		
		MiClase miClase = new MiClase();
		
		// Desde otros paquetes solo puede acceder a los metodos publicos
		miClase.metodoPublic();

	}

}
