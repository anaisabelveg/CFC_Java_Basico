package es.cfc.main;

import es.cfc.models.Cactus;
import es.cfc.models.Planta;
import es.cfc.models.PlantaTropical;

public class TestPlantas {

	public static void main(String[] args) {
		
		Planta plantaTropical = new PlantaTropical("Palmera", true);
		plantaTropical.regar(5, 20);
		
		Planta cactus = new Cactus("Mi cactus", false);
		cactus.regar(1, 40);

	}

}
