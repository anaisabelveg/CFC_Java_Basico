package es.cfc.models;

public abstract class Planta {
	
	private String nombre;
	private boolean exterior;
	
	public Planta() {
		// TODO Auto-generated constructor stub
	}

	public Planta(String nombre, boolean exterior) {
		super();
		this.nombre = nombre;
		this.exterior = exterior;
	}
	
	public abstract void regar(int cantidad, int tiempo);

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public boolean isExterior() {
		return exterior;
	}

	public void setExterior(boolean exterior) {
		this.exterior = exterior;
	}

	@Override
	public String toString() {
		return "Planta [nombre=" + nombre + ", exterior=" + exterior + "]";
	}
	
	

}
