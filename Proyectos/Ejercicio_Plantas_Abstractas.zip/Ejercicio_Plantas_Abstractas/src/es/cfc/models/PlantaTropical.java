package es.cfc.models;

public class PlantaTropical extends Planta{
	
	public PlantaTropical(String nombre, boolean exterior) {
		super(nombre, exterior);
	}

	@Override
	public void regar(int cantidad, int tiempo) {
		System.out.println("Regando la planta tropical");
		System.out.println("La planta " + getNombre() + " se debe regar cada " 
		+ tiempo + " dias con " + cantidad + " litros de agua");
		
	}

}
