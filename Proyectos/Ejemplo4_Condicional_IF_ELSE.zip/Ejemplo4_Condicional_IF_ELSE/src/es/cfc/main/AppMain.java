package es.cfc.main;

public class AppMain {

	public static void main(String[] args) {
		
		String texto = "Jueves";
		
		if (texto.length() == 6) {
			System.out.println("Este texto tiene 6 letras");
		} else {
			System.out.println("Este texto no tiene 6 letras");
		}
		
		
		
		// Ejercicio 1
		int numero = 67;
		
		if (numero % 2 == 0) {
			System.out.println("El numero " + numero + " es par");
		} else {
			System.out.println("El numero " + numero + " es impar");
		}
		
		
		// Ejercicio 2
		int num1 = 17;
		int num2 = 17;
		
		if (num1 > num2) {
			System.out.println(num1 + " es el mayor");
		} else if (num2 > num1) {
			System.out.println(num2 + " es el mayor");
		} else {
			System.out.println("los numeros son iguales ");
		}
		
		
		// Ejercicio 3
		int num3 = 17;
		
		if (num1 >= num2 && num1 >= num3) {
			System.out.println(num1  + " es el mayor");
		} else  if(num2 >= num1 && num2 >= num3) {
			System.out.println(num2 + " es el mayor");
		} else if (num3 >= num1 && num3 >= num2) {
			System.out.println(num3 + " es el mayor");
		} else {
			System.out.println("Los numeros son iguales");
		}
		
		
		// Ejercicio 4
		double capital = 150000;
		int tiempo = 25;
		int redito = 0;
		
		if (tiempo <= 24) {
			redito = 5;
		} else if(tiempo <= 60) {
			redito = 8;
		} else {
			redito = 10;
		}
		
		double resultado = capital * redito * tiempo / 1200;
		System.out.println("Los intereses son " + resultado);
		
		
		// Ejercicio 5
		numero = 4;
		
		if (numero % 2 == 0 && numero % 3 == 0) {
			System.out.println("Es par y multiplo de 3");
		} else if (numero % 2 != 0 && numero % 3 == 0) {
			System.out.println("Es impart y multiplo de 3");
		} else if (numero % 2 == 0 && numero % 3 != 0) {
			System.out.println("El numero es par pero no es multiplo de 3");
		} else {
			System.out.println("Ni es par, ni multiplo de 3");
		}
		
		
		// Ejercicio 6
		double sueldo = 18000;
		int hijos = 2;
		boolean mujer = false;
		int porcentaje = 0;
		
		if (sueldo < 15000) {
			porcentaje = 15;
		} else {
			porcentaje = 12;
		}
		
		// bonus por ser mujer
		if (mujer) {
			porcentaje = porcentaje + 2;
		}
		
		// numero de hijos
		if (hijos > 0) {
			porcentaje = porcentaje + (hijos * 1);
		}

		sueldo = sueldo + (sueldo * porcentaje/100);
		System.out.println("Nuevo sueldo " + sueldo);
		
		
	}

}






