package es.cfc.main;

public class AppMain {

	public static void main(String[] args) {
		
		String texto = "Jueves";
		
		if (texto.length() == 6) {
			System.out.println("Este texto tiene 6 letras");
		} else {
			System.out.println("Este texto no tiene 6 letras");
		}
		
		
		
		// Ejercicio 1
		int numero = 67;
		
		if (numero % 2 == 0) {
			System.out.println("El numero " + numero + " es par");
		} else {
			System.out.println("El numero " + numero + " es impar");
		}
		
		
		// Ejercicio 2
		int num1 = 17;
		int num2 = 17;
		
		if (num1 > num2) {
			System.out.println(num1 + " es el mayor");
		} else if (num2 > num1) {
			System.out.println(num2 + " es el mayor");
		} else {
			System.out.println("los numeros son iguales ");
		}
		
		
		// Ejercicio 3
		int num3 = 17;
		
		if (num1 >= num2 && num1 >= num3) {
			System.out.println(num1  + " es el mayor");
		} else  if(num2 >= num1 && num2 >= num3) {
			System.out.println(num2 + " es el mayor");
		} else if (num3 >= num1 && num3 >= num2) {
			System.out.println(num3 + " es el mayor");
		} else {
			System.out.println("Los numeros son iguales");
		}

	}

}
