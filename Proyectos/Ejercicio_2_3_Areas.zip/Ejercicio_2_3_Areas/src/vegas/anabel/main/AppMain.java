package vegas.anabel.main;

import vegas.anabel.business.Areas;

public class AppMain {

	public static void main(String[] args) {
		// Crear un objeto de la clase Areas
		Areas areas = new Areas();
		
		double circulo = areas.areaCirculo(45);
		System.out.println("El area de un circulo de 45 cm de radio es " + circulo);
		
		System.out.println("El area de un rectagulo 90x35 es " + areas.areaRectangulo(90, 35));

	}

}
