package vegas.anabel.business;

public class Areas {
	
	public double areaCirculo(double radio) {
		//return Math.PI * radio * radio;
		return Math.PI * Math.pow(radio, 2);
	}
	
	public double areaRectangulo(double base, double altura) {
		return base * altura;
	}

}
