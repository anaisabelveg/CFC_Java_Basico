package es.cfc.main;

import es.cfc.models.Circulo;
import es.cfc.models.Figura;
import es.cfc.models.Rectangulo;

public class TestFiguras {

	public static void main(String[] args) {
		
		// No puedo crear un objeto de una clase abstracta
		/*Figura figura = new Figura();
		figura.setCoordenadaX(8);
		figura.setCoordenadaY(12);
		System.out.println(figura.posicion());*/
		
		Figura triangulo = new Figura() {
			
			public int base = 10;
			public int altura = 25;
			
			@Override
			public double calcularArea() {
				// TODO Auto-generated method stub
				return base * altura / 2;
			}
		};
		System.out.println("Area: " + triangulo.calcularArea());
		
		Circulo circulo = new Circulo();
		circulo.setCoordenadaX(5);
		circulo.setCoordenadaY(3);
		circulo.setRadio(9.2);
		System.out.println(circulo.posicion());
		System.out.println("Area: " + circulo.calcularArea());
		
		Rectangulo rectangulo = new Rectangulo();
		rectangulo.setCoordenadaX(1);
		rectangulo.setCoordenadaY(8);
		rectangulo.setBase(9.5);
		rectangulo.setAltura(4.2);
		System.out.println(rectangulo.posicion());
		System.out.println("Area: " + rectangulo.calcularArea());
		

	}

}
