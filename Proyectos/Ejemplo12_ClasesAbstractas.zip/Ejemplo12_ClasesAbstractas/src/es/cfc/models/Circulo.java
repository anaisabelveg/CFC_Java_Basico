package es.cfc.models;

public class Circulo extends Figura {

	private double radio;

	@Override
	public double calcularArea() {
		// TODO Auto-generated method stub
		return Math.PI * Math.pow(radio, 2);
	}

	
	@Override
	public String posicion() {
		// TODO Auto-generated method stub
		return super.posicion() + "radio: " + radio;
	}
	

	public double getRadio() {
		return radio;
	}

	public void setRadio(double radio) {
		this.radio = radio;
	}


	
}
