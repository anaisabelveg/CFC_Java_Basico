package vegas.anabel.main;

public class Monedas {

	public static void main(String[] args) {

		double importe = 163.27;
		int pago = 200;

		double cambio = pago - importe;
		System.out.println(cambio);
		
		// Redondear a dos deciamles
		cambio = Math.round(cambio*100.0)/100.0;
		System.out.println(cambio);

		// Cuantos billetes de 50?
		int billetes50 = (int) (cambio / 50);

		System.out.println(billetes50 + " billetes de 50");

		// actualizar el cambio -> restar los billetes de 50 ya entregados
		cambio = cambio - (billetes50 * 50);

		// Cuantos billetes de 20?
		int billetes20 = (int) (cambio / 20);
		System.out.println(billetes20 + " billetes de 20");
		cambio = cambio - (billetes20 * 20);

		// Cuantos billetes de 10?
		int billetes10 = (int) (cambio / 10);
		System.out.println(billetes10 + " billetes de 10");
		cambio = cambio - (billetes10 * 10);

		// Cuantos billetes de 5?
		int billetes5 = (int) (cambio / 5);
		System.out.println(billetes5 + " billetes de 5");
		cambio = cambio - (billetes5 * 5);

		// Cuantos monedas de 2?
		int monedas2 = (int) (cambio / 2);
		System.out.println(monedas2 + " monedas de 2");
		cambio = cambio - (monedas2 * 2);

		// Cuantos monedas de 1?
		int monedas1 = (int) (cambio / 1);
		System.out.println(monedas1 + " monedas de 1");
		cambio = cambio - (monedas1 * 1);

		// Cuantos monedas de 50 centimos?
		int monedas50 = (int) (cambio / 0.5);
		System.out.println(monedas50 + " monedas de 50 centimos");
		cambio = cambio - (monedas50 * 0.5);

		// Cuantos monedas de 20 centimos?
		int monedas20 = (int) (cambio / 0.2);
		System.out.println(monedas20 + " monedas de 20 centimos");
		cambio = cambio - (monedas20 * 0.2);

		// Cuantos monedas de 10 centimos?
		int monedas10 = (int) (cambio / 0.1);
		System.out.println(monedas10 + " monedas de 10 centimos");
		cambio = cambio - (monedas10 * 0.1);

		// Cuantos monedas de 5 centimos?
		int monedas5 = (int) (cambio / 0.05);
		System.out.println(monedas5 + " monedas de 5 centimos");
		cambio = cambio - (monedas5 * 0.05);

		// Cuantos monedas de 2 centimos?
		int monedas2c = (int) (cambio / 0.02);
		System.out.println(monedas2c + " monedas de 2 centimos");
		cambio = cambio - (monedas2c * 0.02);

		// Cuantos monedas de 1 centimo?
		cambio = Math.round(cambio*100.0)/100.0;
		int monedas1c = (int) (cambio / 0.01);
		System.out.println(monedas1c + " monedas de 1 centimos");
		cambio = cambio - (monedas1c * 0.01);
		
		System.out.println("Cambio final " + cambio);
	}

}
