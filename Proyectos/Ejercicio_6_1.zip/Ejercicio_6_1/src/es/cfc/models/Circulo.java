package es.cfc.models;

public class Circulo extends Figura {

	private double radio;

	@Override
	public String posicion() {
		// TODO Auto-generated method stub
		return super.posicion() + "radio: " + radio;
	}
	

	public double getRadio() {
		return radio;
	}

	public void setRadio(double radio) {
		this.radio = radio;
	}

}
