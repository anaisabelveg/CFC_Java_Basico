package es.cfc.main;

import es.cfc.models.Circulo;
import es.cfc.models.Figura;
import es.cfc.models.Rectangulo;

public class TestFiguras {

	public static void main(String[] args) {
		
		Figura figura = new Figura();
		figura.setCoordenadaX(8);
		figura.setCoordenadaY(12);
		System.out.println(figura.posicion());
		
		Circulo circulo = new Circulo();
		circulo.setCoordenadaX(5);
		circulo.setCoordenadaY(3);
		circulo.setRadio(9.2);
		System.out.println(circulo.posicion());
		
		Rectangulo rectangulo = new Rectangulo();
		rectangulo.setCoordenadaX(1);
		rectangulo.setCoordenadaY(8);
		rectangulo.setBase(9.5);
		rectangulo.setAltura(4.2);
		System.out.println(rectangulo.posicion());
		

	}

}
